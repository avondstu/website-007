﻿( function($) {
  'use strict';
  
	$(window).load(function(){

		$('.loader').fadeOut(300);

	});

})(jQuery);
